# api/views.py
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import ImageUploadSerializer
import cv2
import numpy as np
import pickle
import tensorflow as tf


# Load the model
model = tf.keras.models.load_model("C:\\Users\\RISHI\\Desktop\\sem 5\\FOML\\project\\fackmask\\model.keras")


class FaceMaskDetectionView(APIView):
    def post(self, request, *args, **kwargs):
        serializer = ImageUploadSerializer(data=request.data)
        if serializer.is_valid():
            image_file = serializer.validated_data['image']
            image_array = np.asarray(bytearray(image_file.read()), dtype=np.uint8)
            image = cv2.imdecode(image_array, cv2.IMREAD_COLOR)

            # Preprocess and predict
            processed_image = cv2.resize(image, (224, 224))  # resize based on model input
            prediction = model.predict(np.expand_dims(processed_image, axis=0))

            result = "Mask" if prediction[0][0] == 1 else "No Mask"
            return Response({"prediction": result}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
