# api/urls.py
from django.urls import path
from .views import FaceMaskDetectionView

urlpatterns = [
    path('predict/', FaceMaskDetectionView.as_view(), name='predict')
]
